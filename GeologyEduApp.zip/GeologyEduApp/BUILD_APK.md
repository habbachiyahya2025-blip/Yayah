# بناء ملف APK للاختبار المحلي

إذا كنت تريد اختبار التطبيق على جهازك قبل النشر على Google Play، اتبع هذه الخطوات:

## المتطلبات

- **Android SDK**: تثبيت Android Studio أو Android SDK
- **Java JDK**: إصدار 11 أو أحدث
- **Expo CLI** (اختياري): للبناء السهل

## الطريقة الأولى: باستخدام Expo (الأسهل)

### الخطوة 1: تثبيت Expo CLI

```bash
npm install -g expo-cli
```

### الخطوة 2: تسجيل الدخول إلى Expo

```bash
eas login
```

أدخل بيانات حسابك على Expo (أو أنشئ حساباً جديداً)

### الخطوة 3: بناء APK

```bash
cd /home/ubuntu/GeologyEduApp
eas build --platform android --type apk
```

### الخطوة 4: تحميل الملف

- سيعطيك Expo رابط تحميل الملف
- حمّل ملف APK على جهازك
- انقل الملف إلى جهازك الذكي

### الخطوة 5: تثبيت التطبيق

على جهازك الذكي:
1. اذهب إلى الإعدادات > الأمان
2. فعّل "تثبيت من مصادر غير معروفة"
3. افتح ملف APK
4. انقر على "تثبيت"

---

## الطريقة الثانية: بناء يدوي (متقدم)

### المتطلبات الإضافية

```bash
# تثبيت Android SDK (إذا لم تكن مثبتاً)
# أو استخدم Android Studio

# تعيين متغيرات البيئة
export ANDROID_SDK_ROOT=/path/to/android-sdk
export ANDROID_HOME=/path/to/android-sdk
```

### بناء APK

```bash
cd /home/ubuntu/GeologyEduApp

# 1. إنشاء مفتاح التوقيع (لمرة واحدة فقط)
keytool -genkey -v -keystore geologyedu.keystore \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias geologyedu

# 2. بناء APK
npm run build

# 3. التوقيع على APK
jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 \
  -keystore geologyedu.keystore \
  dist/app-release-unsigned.apk geologyedu

# 4. محاذاة APK
zipalign -v 4 dist/app-release-unsigned.apk dist/app-release.apk
```

---

## اختبار التطبيق

### على محاكي Android

```bash
# تشغيل محاكي Android Studio أولاً

# ثم تثبيت APK
adb install dist/app-release.apk

# أو
adb install -r dist/app-release.apk  # لإعادة التثبيت
```

### على جهاز فعلي

1. وصّل جهازك بالكمبيوتر عبر USB
2. فعّل "وضع المطور" على الجهاز
3. شغّل:
   ```bash
   adb install dist/app-release.apk
   ```

---

## استكشاف الأخطاء

### المشكلة: "keytool not found"

**الحل**: تأكد من تثبيت Java JDK وإضافته إلى PATH

```bash
# تحقق من تثبيت Java
java -version

# إذا لم يكن مثبتاً، ثبّت JDK
# على Ubuntu:
sudo apt-get install default-jdk

# على macOS:
brew install openjdk
```

### المشكلة: "Android SDK not found"

**الحل**: ثبّت Android Studio أو Android SDK

```bash
# على Ubuntu:
sudo apt-get install android-sdk

# على macOS:
brew install android-sdk
```

### المشكلة: "adb command not found"

**الحل**: أضف Android SDK إلى PATH

```bash
export PATH=$PATH:~/Android/Sdk/platform-tools
```

---

## التحقق من التطبيق

بعد التثبيت، اختبر:

1. **الصفحة الرئيسية**: هل تظهر الدروس بشكل صحيح؟
2. **عرض الدرس**: انقر على درس وتحقق من المحتوى
3. **الفلاتر**: جرّب تصفية الدروس حسب الفئة
4. **الإدارة**: 
   - انقر على زر الإدارة
   - أدخل كلمة المرور: `يحي الحباشي`
   - جرّب إضافة درس جديد
   - جرّب تعديل درس موجود
   - جرّب حذف درس

---

## نصائح مهمة

1. **اختبر على أجهزة مختلفة**: اختبر على هواتف بأحجام وإصدارات مختلفة
2. **اختبر الاتصال**: تأكد من أن الإنترنت يعمل بشكل صحيح
3. **اختبر الأداء**: تحقق من سرعة التطبيق وعدم التأخر
4. **اختبر الواجهة**: تأكد من أن جميع الأزرار والروابط تعمل

---

## بعد الاختبار الناجح

إذا عمل التطبيق بشكل صحيح:

1. احفظ ملف APK في مكان آمن
2. استخدم نفس المفتاح (geologyedu.keystore) لبناء AAB للنشر
3. اتبع خطوات النشر على Google Play

---

## الدعم

إذا واجهت مشاكل:

1. تحقق من [مستندات React Native](https://reactnative.dev/)
2. اطلع على [مستندات Android](https://developer.android.com/)
3. ابحث عن الخطأ على Google

---

**ملاحظة**: الطريقة الأولى (Expo) أسهل وموصى بها للمبتدئين!
