import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, BookOpen, Settings } from "lucide-react";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { useLocation } from "wouter";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [location, setLocation] = useLocation();
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  
  // Fetch all lessons
  const { data: allLessons, isLoading } = trpc.lessons.list.useQuery();
  
  // Get unique categories
  const categories = Array.from(
    new Set(allLessons?.map(lesson => lesson.category) || [])
  );

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="animate-spin w-8 h-8" />
      </div>
    );
  }

  const filteredLessons = selectedCategory
    ? allLessons?.filter(lesson => lesson.category === selectedCategory)
    : allLessons;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-6 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-emerald-600 rounded-lg flex items-center justify-center">
              <BookOpen className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900">علوم الحياة والأرض</h1>
          </div>
          <div className="flex items-center gap-3">
            {isAuthenticated && user?.role === 'admin' && (
              <Button
                onClick={() => setLocation('/admin')}
                variant="outline"
                size="sm"
                className="gap-2"
              >
                <Settings className="w-4 h-4" />
                الإدارة
              </Button>
            )}
            {isAuthenticated ? (
              <div className="text-sm text-gray-600">
                مرحباً، {user?.name || 'المستخدم'}
              </div>
            ) : (
              <Button
                onClick={() => window.location.href = getLoginUrl()}
                size="sm"
              >
                دخول
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">
            مرحباً بك في منصة التعلم التفاعلية
          </h2>
          <p className="text-gray-600">
            ملخص شامل لدروس علوم الحياة والأرض مع صور توضيحية وشرح مفصل
          </p>
        </div>

        {/* Categories Filter */}
        <div className="mb-8">
          <div className="flex flex-wrap gap-2">
            <Button
              onClick={() => setSelectedCategory(null)}
              variant={selectedCategory === null ? 'default' : 'outline'}
              className="rounded-full"
            >
              جميع الدروس
            </Button>
            {categories.map(category => (
              <Button
                key={category}
                onClick={() => setSelectedCategory(category)}
                variant={selectedCategory === category ? 'default' : 'outline'}
                className="rounded-full"
              >
                {category}
              </Button>
            ))}
          </div>
        </div>

        {/* Lessons Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredLessons && filteredLessons.length > 0 ? (
            filteredLessons.map(lesson => (
              <LessonCard
                key={lesson.id}
                lesson={lesson}
                onSelect={() => setLocation(`/lesson/${lesson.id}`)}
              />
            ))
          ) : (
            <div className="col-span-full text-center py-12">
              <p className="text-gray-500">لا توجد دروس متاحة حالياً</p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

interface LessonCardProps {
  lesson: {
    id: number;
    title: string;
    description: string | null;
    category: string;
    imageUrl: string | null;
  };
  onSelect: () => void;
}

function LessonCard({ lesson, onSelect }: LessonCardProps) {
  return (
    <Card
      className="cursor-pointer hover:shadow-lg transition-shadow h-full"
      onClick={onSelect}
    >
      {lesson.imageUrl && (
        <div className="w-full h-40 bg-gray-200 overflow-hidden rounded-t-lg">
          <img
            src={lesson.imageUrl}
            alt={lesson.title}
            className="w-full h-full object-cover"
          />
        </div>
      )}
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle className="text-lg">{lesson.title}</CardTitle>
            <CardDescription className="mt-1">{lesson.category}</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {lesson.description && (
          <p className="text-sm text-gray-600 line-clamp-2">
            {lesson.description}
          </p>
        )}
      </CardContent>
    </Card>
  );
}
