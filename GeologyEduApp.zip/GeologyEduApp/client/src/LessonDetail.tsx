import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Loader2, ArrowRight, Edit2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { Streamdown } from "streamdown";

interface LessonDetailProps {
  params: {
    id: string;
  };
}

export default function LessonDetail({ params }: LessonDetailProps) {
  const [location, setLocation] = useLocation();
  const { user } = useAuth();
  const lessonId = parseInt(params.id);

  const { data: lesson, isLoading } = trpc.lessons.byId.useQuery(
    { id: lessonId },
    { enabled: !isNaN(lessonId) }
  );

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="animate-spin w-8 h-8" />
      </div>
    );
  }

  if (!lesson) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <p className="text-gray-500 mb-4">الدرس غير موجود</p>
        <Button onClick={() => setLocation('/')}>
          العودة للرئيسية
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-4xl mx-auto px-4 py-6 flex justify-between items-center">
          <Button
            onClick={() => setLocation('/')}
            variant="ghost"
            className="gap-2"
          >
            <ArrowRight className="w-4 h-4" />
            العودة
          </Button>
          {user?.role === 'admin' && (
            <Button
              onClick={() => setLocation(`/admin/lesson/${lessonId}`)}
              variant="outline"
              size="sm"
              className="gap-2"
            >
              <Edit2 className="w-4 h-4" />
              تعديل
            </Button>
          )}
        </div>
      </header>

      {/* Content */}
      <main className="max-w-4xl mx-auto px-4 py-8">
        {/* Lesson Image */}
        {lesson.imageUrl && (
          <div className="mb-8 rounded-lg overflow-hidden shadow-lg">
            <img
              src={lesson.imageUrl}
              alt={lesson.title}
              className="w-full h-96 object-cover"
            />
          </div>
        )}

        {/* Lesson Header */}
        <div className="mb-8">
          <div className="inline-block bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium mb-4">
            {lesson.category}
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            {lesson.title}
          </h1>
          {lesson.description && (
            <p className="text-lg text-gray-600">
              {lesson.description}
            </p>
          )}
        </div>

        {/* Lesson Content */}
        <div className="bg-white rounded-lg shadow-md p-8 prose prose-sm max-w-none">
          <Streamdown>{lesson.content}</Streamdown>
        </div>
      </main>
    </div>
  );
}
