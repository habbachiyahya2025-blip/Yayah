import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Loader2, LogOut, Plus, Edit2, Trash2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";

export default function Admin() {
  const [location, setLocation] = useLocation();
  const { user, logout, isAuthenticated } = useAuth();
  const [password, setPassword] = useState("");
  const [isPasswordCorrect, setIsPasswordCorrect] = useState(false);

  // Fetch all lessons
  const { data: allLessons, isLoading, refetch } = trpc.lessons.list.useQuery();

  // Delete mutation
  const deleteMutation = trpc.lessons.delete.useMutation({
    onSuccess: () => {
      toast.success("تم حذف الدرس بنجاح");
      refetch();
    },
    onError: (error) => {
      toast.error("خطأ: " + error.message);
    },
  });

  // Check password
  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === "يحي الحباشي") {
      setIsPasswordCorrect(true);
      setPassword("");
    } else {
      toast.error("كلمة المرور غير صحيحة");
      setPassword("");
    }
  };

  // If not authenticated, redirect to login
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>دخول الإدارة</CardTitle>
            <CardDescription>
              يرجى تسجيل الدخول أولاً
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button
              onClick={() => window.location.href = "https://api.manus.im/oauth/authorize?client_id=test"}
              className="w-full"
            >
              تسجيل الدخول
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // If not admin, show error
  if (user?.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>غير مصرح</CardTitle>
            <CardDescription>
              ليس لديك صلاحيات الإدارة
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button
              onClick={() => setLocation('/')}
              className="w-full"
            >
              العودة للرئيسية
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // If password not verified, show password form
  if (!isPasswordCorrect) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>التحقق من كلمة المرور</CardTitle>
            <CardDescription>
              أدخل كلمة المرور للوصول إلى لوحة الإدارة
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handlePasswordSubmit} className="space-y-4">
              <Input
                type="password"
                placeholder="كلمة المرور"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="text-right"
              />
              <Button type="submit" className="w-full">
                تحقق
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-6 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-900">لوحة الإدارة</h1>
          <div className="flex items-center gap-3">
            <span className="text-sm text-gray-600">{user?.name}</span>
            <Button
              onClick={() => {
                logout();
                setLocation('/');
              }}
              variant="outline"
              size="sm"
              className="gap-2"
            >
              <LogOut className="w-4 h-4" />
              تسجيل الخروج
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-8">
        {/* Add New Lesson Button */}
        <div className="mb-8">
          <Button
            onClick={() => setLocation('/admin/lesson/new')}
            className="gap-2"
            size="lg"
          >
            <Plus className="w-5 h-5" />
            إضافة درس جديد
          </Button>
        </div>

        {/* Lessons Table */}
        <Card>
          <CardHeader>
            <CardTitle>الدروس المتاحة</CardTitle>
            <CardDescription>
              إدارة الدروس التعليمية
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="animate-spin w-6 h-6" />
              </div>
            ) : allLessons && allLessons.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="border-b">
                    <tr>
                      <th className="text-right py-3 px-4 font-semibold">العنوان</th>
                      <th className="text-right py-3 px-4 font-semibold">الفئة</th>
                      <th className="text-right py-3 px-4 font-semibold">التاريخ</th>
                      <th className="text-right py-3 px-4 font-semibold">الإجراءات</th>
                    </tr>
                  </thead>
                  <tbody>
                    {allLessons.map(lesson => (
                      <tr key={lesson.id} className="border-b hover:bg-gray-50">
                        <td className="py-3 px-4">{lesson.title}</td>
                        <td className="py-3 px-4">{lesson.category}</td>
                        <td className="py-3 px-4 text-gray-500 text-xs">
                          {new Date(lesson.createdAt).toLocaleDateString('ar-SA')}
                        </td>
                        <td className="py-3 px-4 flex gap-2">
                          <Button
                            onClick={() => setLocation(`/admin/lesson/${lesson.id}`)}
                            variant="outline"
                            size="sm"
                            className="gap-1"
                          >
                            <Edit2 className="w-4 h-4" />
                            تعديل
                          </Button>
                          <Button
                            onClick={() => {
                              if (confirm('هل أنت متأكد من حذف هذا الدرس؟')) {
                                deleteMutation.mutate({ id: lesson.id });
                              }
                            }}
                            variant="destructive"
                            size="sm"
                            className="gap-1"
                            disabled={deleteMutation.isPending}
                          >
                            <Trash2 className="w-4 h-4" />
                            حذف
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-gray-500">لا توجد دروس حالياً</p>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
