import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, ArrowRight } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";

interface AdminLessonEditProps {
  params: {
    id: string;
  };
}

export default function AdminLessonEdit({ params }: AdminLessonEditProps) {
  const [location, setLocation] = useLocation();
  const { user } = useAuth();
  const isNewLesson = params.id === 'new';
  const lessonId = isNewLesson ? null : parseInt(params.id);

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    content: "",
    imageUrl: "",
    category: "",
    order: 0,
  });

  // Fetch lesson if editing
  const { data: lesson, isLoading: isLoadingLesson } = trpc.lessons.byId.useQuery(
    { id: lessonId ?? 0 },
    { enabled: !isNewLesson }
  );

  // Populate form when lesson loads
  useEffect(() => {
    if (lesson) {
      setFormData({
        title: lesson.title,
        description: lesson.description || "",
        content: lesson.content,
        imageUrl: lesson.imageUrl || "",
        category: lesson.category,
        order: lesson.order,
      });
    }
  }, [lesson]);

  // Upsert mutation
  const upsertMutation = trpc.lessons.upsert.useMutation({
    onSuccess: () => {
      toast.success(isNewLesson ? "تم إضافة الدرس بنجاح" : "تم تحديث الدرس بنجاح");
      setLocation('/admin');
    },
    onError: (error) => {
      toast.error("خطأ: " + error.message);
    },
  });

  // If not admin, redirect
  if (user?.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-gray-500">غير مصرح</p>
      </div>
    );
  }

  if (isLoadingLesson) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="animate-spin w-8 h-8" />
      </div>
    );
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.title || !formData.content || !formData.category) {
      toast.error("يرجى ملء جميع الحقول المطلوبة");
      return;
    }

    upsertMutation.mutate({
      id: lessonId ?? undefined,
      title: formData.title,
      description: formData.description || undefined,
      content: formData.content,
      imageUrl: formData.imageUrl || undefined,
      category: formData.category,
      order: formData.order,
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <Button
            onClick={() => setLocation('/admin')}
            variant="ghost"
            className="gap-2"
          >
            <ArrowRight className="w-4 h-4" />
            العودة
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-8">
        <Card>
          <CardHeader>
            <CardTitle>
              {isNewLesson ? "إضافة درس جديد" : "تعديل الدرس"}
            </CardTitle>
            <CardDescription>
              {isNewLesson ? "إنشاء درس تعليمي جديد" : "تحديث محتوى الدرس"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Title */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  العنوان *
                </label>
                <Input
                  type="text"
                  value={formData.title}
                  onChange={(e) =>
                    setFormData({ ...formData, title: e.target.value })
                  }
                  placeholder="عنوان الدرس"
                  className="text-right"
                />
              </div>

              {/* Category */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  الفئة *
                </label>
                <Input
                  type="text"
                  value={formData.category}
                  onChange={(e) =>
                    setFormData({ ...formData, category: e.target.value })
                  }
                  placeholder="مثال: الوسط البيئي"
                  className="text-right"
                />
              </div>

              {/* Description */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  الوصف
                </label>
                <Textarea
                  value={formData.description}
                  onChange={(e) =>
                    setFormData({ ...formData, description: e.target.value })
                  }
                  placeholder="وصف مختصر للدرس"
                  className="text-right"
                  rows={3}
                />
              </div>

              {/* Image URL */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  رابط الصورة
                </label>
                <Input
                  type="url"
                  value={formData.imageUrl}
                  onChange={(e) =>
                    setFormData({ ...formData, imageUrl: e.target.value })
                  }
                  placeholder="https://example.com/image.jpg"
                  className="text-right"
                />
              </div>

              {/* Order */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  الترتيب
                </label>
                <Input
                  type="number"
                  value={formData.order}
                  onChange={(e) =>
                    setFormData({ ...formData, order: parseInt(e.target.value) || 0 })
                  }
                  placeholder="0"
                  min="0"
                />
              </div>

              {/* Content */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  المحتوى (Markdown) *
                </label>
                <Textarea
                  value={formData.content}
                  onChange={(e) =>
                    setFormData({ ...formData, content: e.target.value })
                  }
                  placeholder="محتوى الدرس بصيغة Markdown"
                  className="text-right font-mono"
                  rows={12}
                />
                <p className="text-xs text-gray-500 mt-2">
                  يمكنك استخدام صيغة Markdown للتنسيق
                </p>
              </div>

              {/* Submit Button */}
              <div className="flex gap-3 justify-end">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setLocation('/admin')}
                >
                  إلغاء
                </Button>
                <Button
                  type="submit"
                  disabled={upsertMutation.isPending}
                  className="gap-2"
                >
                  {upsertMutation.isPending && (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  )}
                  {isNewLesson ? "إضافة" : "تحديث"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
