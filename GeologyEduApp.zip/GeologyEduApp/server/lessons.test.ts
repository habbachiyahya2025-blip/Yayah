import { describe, expect, it, beforeAll } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock user context
const mockAdminUser = {
  id: 1,
  openId: "admin-user",
  email: "admin@example.com",
  name: "Admin User",
  loginMethod: "manus",
  role: "admin" as const,
  createdAt: new Date(),
  updatedAt: new Date(),
  lastSignedIn: new Date(),
};

const mockRegularUser = {
  id: 2,
  openId: "regular-user",
  email: "user@example.com",
  name: "Regular User",
  loginMethod: "manus",
  role: "user" as const,
  createdAt: new Date(),
  updatedAt: new Date(),
  lastSignedIn: new Date(),
};

function createMockContext(user: typeof mockAdminUser | null): TrpcContext {
  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("lessons router", () => {
  describe("list", () => {
    it("returns empty array initially", async () => {
      const ctx = createMockContext(null);
      const caller = appRouter.createCaller(ctx);
      const result = await caller.lessons.list();
      expect(Array.isArray(result)).toBe(true);
    });
  });

  describe("byCategory", () => {
    it("returns lessons for a category", async () => {
      const ctx = createMockContext(null);
      const caller = appRouter.createCaller(ctx);
      const result = await caller.lessons.byCategory({ category: "test" });
      expect(Array.isArray(result)).toBe(true);
    });
  });

  describe("byId", () => {
    it("returns undefined for non-existent lesson", async () => {
      const ctx = createMockContext(null);
      const caller = appRouter.createCaller(ctx);
      const result = await caller.lessons.byId({ id: 999 });
      expect(result).toBeUndefined();
    });
  });

  describe("upsert", () => {
    it("rejects unauthenticated users", async () => {
      const ctx = createMockContext(null);
      const caller = appRouter.createCaller(ctx);
      
      try {
        await caller.lessons.upsert({
          title: "Test Lesson",
          content: "Test content",
          category: "Test",
        });
        expect.fail("Should have thrown");
      } catch (error: any) {
        expect(error.code).toBe("UNAUTHORIZED");
      }
    });

    it("rejects non-admin users", async () => {
      const ctx = createMockContext(mockRegularUser);
      const caller = appRouter.createCaller(ctx);
      
      try {
        await caller.lessons.upsert({
          title: "Test Lesson",
          content: "Test content",
          category: "Test",
        });
        expect.fail("Should have thrown");
      } catch (error: any) {
        expect(error.code).toBe("FORBIDDEN");
      }
    });

    it("allows admin users to create lessons", async () => {
      const ctx = createMockContext(mockAdminUser);
      const caller = appRouter.createCaller(ctx);
      
      const result = await caller.lessons.upsert({
        title: "Test Lesson",
        content: "Test content",
        category: "Test Category",
        description: "Test description",
      });
      
      expect(result).toEqual({ success: true });
    });
  });

  describe("delete", () => {
    it("rejects unauthenticated users", async () => {
      const ctx = createMockContext(null);
      const caller = appRouter.createCaller(ctx);
      
      try {
        await caller.lessons.delete({ id: 1 });
        expect.fail("Should have thrown");
      } catch (error: any) {
        expect(error.code).toBe("UNAUTHORIZED");
      }
    });

    it("rejects non-admin users", async () => {
      const ctx = createMockContext(mockRegularUser);
      const caller = appRouter.createCaller(ctx);
      
      try {
        await caller.lessons.delete({ id: 1 });
        expect.fail("Should have thrown");
      } catch (error: any) {
        expect(error.code).toBe("FORBIDDEN");
      }
    });
  });
});
