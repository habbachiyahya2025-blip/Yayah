import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { getAllLessons, getLessonsByCategory, getLessonById, upsertLesson, deleteLesson } from "./db";
import { z } from "zod";
import { TRPCError } from "@trpc/server";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  lessons: router({
    // Get all lessons
    list: publicProcedure.query(() => getAllLessons()),
    
    // Get lessons by category
    byCategory: publicProcedure
      .input(z.object({ category: z.string() }))
      .query(({ input }) => getLessonsByCategory(input.category)),
    
    // Get a single lesson
    byId: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(({ input }) => getLessonById(input.id)),
    
    // Create or update lesson (admin only)
    upsert: protectedProcedure
      .input(z.object({
        id: z.number().optional(),
        title: z.string(),
        description: z.string().optional(),
        content: z.string(),
        imageUrl: z.string().optional(),
        category: z.string(),
        order: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== 'admin') {
          throw new TRPCError({ code: 'FORBIDDEN' });
        }
        await upsertLesson(input);
        return { success: true };
      }),
    
    // Delete lesson (admin only)
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== 'admin') {
          throw new TRPCError({ code: 'FORBIDDEN' });
        }
        await deleteLesson(input.id);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
